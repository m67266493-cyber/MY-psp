#include <jni.h>
#include <string>
#include <android/log.h>

#define LOG_TAG "MYPSP_NATIVE"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

// هذا الملف هو الجسر JNI.
// إذا لم يتم ربط PPSSPP بعد، isEngineAvailable يرجع false بصدق
// ولا يتم ادعاء تشغيل أي لعبة.

extern bool ppsspp_is_available();
extern std::string ppsspp_get_version();
extern bool ppsspp_launch_game(const std::string &path);
extern void ppsspp_send_input(const std::string &button, bool pressed);
extern void ppsspp_set_analog(float x, float y);

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mypsp_NativeBridge_isEngineAvailable(JNIEnv *env, jobject thiz) {
    return ppsspp_is_available() ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_mypsp_NativeBridge_getEngineVersion(JNIEnv *env, jobject thiz) {
    if (!ppsspp_is_available()) return env->NewStringUTF("NOT_CONNECTED");
    return env->NewStringUTF(ppsspp_get_version().c_str());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_mypsp_NativeBridge_launchGameNative(JNIEnv *env, jobject thiz, jstring path_) {
    const char* path = env->GetStringUTFChars(path_, nullptr);
    std::string p(path ? path : "");
    env->ReleaseStringUTFChars(path_, path);
    if (!ppsspp_is_available()) {
        LOGI("Launch blocked - engine not connected");
        return JNI_FALSE;
    }
    return ppsspp_launch_game(p) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_mypsp_NativeBridge_sendInput(JNIEnv *env, jobject thiz, jstring button_, jboolean pressed) {
    if (!ppsspp_is_available()) return;
    const char* b = env->GetStringUTFChars(button_, nullptr);
    ppsspp_send_input(b ? b : "", pressed == JNI_TRUE);
    env->ReleaseStringUTFChars(button_, b);
}

extern "C" JNIEXPORT void JNICALL
Java_com_mypsp_NativeBridge_setAnalog(JNIEnv *env, jobject thiz, jfloat x, jfloat y) {
    if (!ppsspp_is_available()) return;
    ppsspp_set_analog(x, y);
}
