// ppsspp_integration.cpp
// ============================================================
// نقطة ربط PPSSPP الرسمي - هذا هو المكان الوحيد الذي تربط فيه المحرك.
// ============================================================
// الخطوات الرسمية:
// 1. git submodule update --init --recursive  (يسحب https://github.com/hrydgard/ppsspp)
// 2. اتبع ملف BUILDING.md داخل مجلد ppsspp/ لبناء Core للأندرويد
// 3. استبدل الدوال الـ Stub أدناه باستدعاءات PPSSPP الحقيقية:
//
//    مثال (بعد الربط):
//    #include "ppsspp/Core/System.h"
//    #include "ppsspp/Core/Config.h"
//    bool ppsspp_is_available() { return true; }
//    std::string ppsspp_get_version() { return PPSSPP_VERSION; }
//    bool ppsspp_launch_game(...) { return PSP_Load(...); }
//
// حتى يتم ذلك، الدوال ترجع false بصدق ولا تدّعي التشغيل.
// ============================================================

#include <string>

bool ppsspp_is_available() {
    // TODO: بعد ربط PPSSPP الرسمي، أعد هذه إلى true
    return false;
}

std::string ppsspp_get_version() {
    return "NOT_CONNECTED";
}

bool ppsspp_launch_game(const std::string &path) {
    // لم يتم الربط بعد - لا تشغّل شيئاً وهمياً
    (void)path;
    return false;
}

void ppsspp_send_input(const std::string &button, bool pressed) {
    (void)button; (void)pressed;
}

void ppsspp_set_analog(float x, float y) {
    (void)x; (void)y;
}
