package com.mypsp

/**
 * NativeBridge - يربط Kotlin بـ C++ عبر JNI
 * التنفيذ الحقيقي في app/src/main/cpp/native-lib.cpp
 */
object NativeBridge {
    init {
        try {
            System.loadLibrary("mypsp_native")
        } catch (e: UnsatisfiedLinkError) {
            // المكتبة غير مترجمة بعد - هذا طبيعي قبل بناء NDK
            // isEngineAvailable سيرجع false بصدق
        }
    }

    external fun isEngineAvailable(): Boolean
    external fun getEngineVersion(): String
    external fun launchGameNative(path: String): Boolean
    external fun sendInput(button: String, pressed: Boolean)
    external fun setAnalog(x: Float, y: Float)
}
