package com.mypsp

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

/**
 * EngineZipLoader - فكرة المستخدم: زر يفتح ملف ZIP فيه النظام الحقيقي
 *
 * كيف تعمل؟
 * 1. المستخدم يضغط "تحميل النظام من ZIP" في شاشة System
 * 2. يختار ملف ZIP من تلفونه (اللي فيه نظام PPSSPP الحقيقي)
 * 3. نفك الضغط في مجلد خاص بالتطبيق: filesDir/engine/
 * 4. نتحقق أن الملفات الأساسية موجودة
 * 5. إذا صح، نعتبر المحرك متصل ونحفظ مساره
 *
 * مهم: الـ ZIP لازم يكون فيه ملفات PPSSPP الأساسية، مو أي ZIP.
 * مثال على المحتوى الصح:
 *   engine/libppsspp.so  أو  ppsspp/libppsspp.so
 *   engine/config.ini
 *   engine/assets/...
 * لا تقبل ملفات ألعاب ISO أو ملفات Firmware من سوني هنا.
 */
object EngineZipLoader {

    private const val ENGINE_DIR = "engine"
    private const val PREFS = "mypsp_engine"
    private const val KEY_ENGINE_PATH = "engine_path"
    private const val KEY_ENGINE_LOADED = "engine_loaded"

    fun getEngineDir(context: Context): File {
        return File(context.filesDir, ENGINE_DIR)
    }

    fun isEngineLoaded(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val loaded = prefs.getBoolean(KEY_ENGINE_LOADED, false)
        val dir = getEngineDir(context)
        return loaded && dir.exists() && dir.listFiles()?.isNotEmpty() == true
    }

    /**
     * فك ضغط ZIP والتحقق منه. ترجع Pair<نجح؟, رسالة>
     */
    fun loadFromZip(context: Context, zipUri: Uri): Pair<Boolean, String> {
        return try {
            val engineDir = getEngineDir(context)
            if (engineDir.exists()) engineDir.deleteRecursively()
            engineDir.mkdirs()

            var fileCount = 0
            var foundSo = false
            var foundConfigOrCore = false

            context.contentResolver.openInputStream(zipUri)?.use { input ->
                ZipInputStream(input).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory) {
                            // حماية من Zip Slip: لا نسمح بمسارات تخرج خارج مجلد المحرك
                            val outFile = File(engineDir, effectiveName).canonicalFile
                            if (!outFile.path.startsWith(engineDir.canonicalFile.path)) {
                                return Pair(false, "ملف غير آمن داخل ZIP: $effectiveName")
                            }
                            outFile.parentFile?.mkdirs()
                            FileOutputStream(outFile).use { out ->
                                zis.copyTo(out)
                            }
                            fileCount++
                            val lower = entry.name.lowercase()
                            if (lower.endsWith(".so")) foundSo = true
                            if (lower.contains("ppsspp") || lower.endsWith(".ini") || lower.endsWith(".cfg")) {
                                foundConfigOrCore = true
                            }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            } ?: return Pair(false, "ما قدرت أفتح ملف ZIP")

            if (fileCount == 0) {
                return Pair(false, "الـ ZIP فاضي، ما فيه ملفات")
            }
            // تحقق مرن: نقبل إذا فيه ملف .so أو ملفات PPSSPP واضحة
            // إذا كان ZIP فيه مجلد PPSSPP كامل، بيكون فيه .so
            if (!foundSo && !foundConfigOrCore) {
                return Pair(false, "هذا ZIP ما يبين أنه نظام PPSSPP. تأكد أن ZIP فيه ملفات النظام، مو لعبة ISO.")
            }

            // حفظ أن المحرك تم تحميله
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_ENGINE_LOADED, true)
                .putString(KEY_ENGINE_PATH, engineDir.absolutePath)
                .apply()

            // بعد التحميل، أخبر NativeBridge أن المحرك صار موجوداً
            NativeBridge.setEnginePath(engineDir.absolutePath)

            Pair(true, "تم تحميل النظام بنجاح! عدد الملفات: $fileCount - أعد تشغيل التطبيق وجرّب Launch")

        } catch (e: Exception) {
            Pair(false, "خطأ أثناء فك ZIP: ${e.message}")
        }
    }

    fun clearEngine(context: Context) {
        getEngineDir(context).deleteRecursively()
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun getEngineInfo(context: Context): String {
        val dir = getEngineDir(context)
        if (!isEngineLoaded(context)) return "لا يوجد نظام محمّل"
        val count = dir.walkTopDown().count { it.isFile }
        return "النظام محمّل من ZIP - $count ملف في ${dir.absolutePath}"
    }
}
