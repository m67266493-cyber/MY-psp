package com.mypsp

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * يدير قائمة الألعاب المضافة من قبل المستخدم فقط.
 * لا يحتوي على أي لعبة مدمجة.
 */
data class GameEntry(val id: String, val title: String, val path: String, val size: Long, val format: String)

object GameLibraryManager {
    private const val PREFS = "mypsp_library"
    private const val KEY = "games_json"

    fun addGame(context: Context, file: File): GameEntry {
        val entry = GameEntry(
            id = file.absolutePath.hashCode().toString(),
            title = file.nameWithoutExtension,
            path = file.absolutePath,
            size = file.length(),
            format = file.extension.uppercase()
        )
        val list = getGames(context).toMutableList()
        list.removeAll { it.path == entry.path }
        list.add(entry)
        save(context, list)
        return entry
    }

    fun getGames(context: Context): List<GameEntry> {
        val json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(json)
        val out = mutableListOf<GameEntry>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(GameEntry(o.getString("id"), o.getString("title"), o.getString("path"), o.getLong("size"), o.getString("format")))
        }
        return out
    }

    private fun save(context: Context, list: List<GameEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id); put("title", it.title); put("path", it.path); put("size", it.size); put("format", it.format)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
