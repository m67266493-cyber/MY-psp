package com.mypsp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.app.Activity
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * MY PSP - MainActivity
 * يعرض واجهة MY PSP من assets/www/index.html داخل WebView
 * ويربطها بجسر PPSSPP عبر PpssppBridge
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var bridge: PpssppBridge
    private val engineZipPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            val (ok, msg) = EngineZipLoader.loadFromZip(this, uri)
            val js = if (ok) "window.dispatchEvent(new CustomEvent('mypsp-engine-zip-loaded', {detail: `$msg`}))"
                     else "window.dispatchEvent(new CustomEvent('mypsp-engine-zip-failed', {detail: `$msg`}))"
            webView.evaluateJavascript(js, null)
            // حدّث حالة الجسر في الواجهة
            webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('mypsp-engine-status-changed'))", null)
        }
    }
    fun openEngineZipPicker() {
        engineZipPicker.launch("application/zip")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        setContentView(webView)

        bridge = PpssppBridge(this, webView,
            onLaunchRequest = { path -> openGameActivity(path) }
        )

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // الجسر: JavaScript في الواجهة يستطيع استدعاء window.MYPSP_Bridge
        webView.addJavascriptInterface(bridge, "MYPSP_Bridge")

        webView.loadUrl("file:///android_asset/www/index.html")
    }

    private fun openGameActivity(path: String) {
        // إذا المحرك غير متصل، لا نفتح شاشة لعب وهمية
        if (!NativeBridge.isEngineAvailable()) {
            bridge.notifyEngineNotConnected()
            return
        }
        val intent = Intent(this, GameActivity::class.java).apply {
            putExtra("game_path", path)
        }
        startActivity(intent)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
