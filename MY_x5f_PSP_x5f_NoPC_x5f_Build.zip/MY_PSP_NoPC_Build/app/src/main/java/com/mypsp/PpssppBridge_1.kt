package com.mypsp

import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject

/**
 * PpssppBridge - الجسر الرسمي بين واجهة MY PSP والمحرك
 *
 * يستدعى من JavaScript هكذا:
 *   window.MYPSP_Bridge.isEngineAvailable()
 *   window.MYPSP_Bridge.launchGame("/storage/.../game.iso")
 *   window.MYPSP_Bridge.getEngineVersion()
 *
 * مهم: لا يعود أبداً بـ "تم التشغيل بنجاح" إذا المحرك غير متصل.
 */
class PpssppBridge(
    private val context: Context,
    private val webView: WebView,
    private val onLaunchRequest: (String) -> Unit
) {

    @JavascriptInterface
    fun isEngineAvailable(): Boolean {
        return NativeBridge.isEngineAvailable()
    }

    @JavascriptInterface
    fun getEngineVersion(): String {
        return if (NativeBridge.isEngineAvailable()) {
            NativeBridge.getEngineVersion()
        } else {
            "NOT_CONNECTED"
        }
    }

    @JavascriptInterface
    fun getBridgeStatus(): String {
        val obj = JSONObject()
        obj.put("bridge", "MYPSP_Bridge")
        obj.put("engine", if (NativeBridge.isEngineAvailable()) "PPSSPP_CONNECTED" else "NOT_CONNECTED")
        obj.put("engineVersion", getEngineVersion())
        obj.put("app", "MY PSP 1.0.0")
        return obj.toString()
    }

    @JavascriptInterface
    fun launchGame(path: String): String {
        if (path.isBlank()) return errorJson("EMPTY_PATH", "مسار اللعبة فارغ")
        if (!NativeBridge.isEngineAvailable()) {
            notifyEngineNotConnected()
            return errorJson("ENGINE_NOT_CONNECTED", "محرك PPSSPP غير متصل. أكمل خطوات ربط المحرك في README")
        }
        // تحقق بسيط من الصيغة
        val lower = path.lowercase()
        if (!(lower.endsWith(".iso") || lower.endsWith(".cso") || lower.endsWith(".pbp"))) {
            return errorJson("UNSUPPORTED_FORMAT", "الصيغة غير مدعومة. استخدم ISO / CSO / PBP فقط")
        }
        onLaunchRequest(path)
        return successJson("LAUNCH_REQUESTED", path)
    }

    @JavascriptInterface
    fun sendInput(button: String, pressed: Boolean) {
        // يرسل أزرار الكنترولر الافتراضي إلى المحرك
        // مثال: "CROSS", "CIRCLE", "DPAD_UP", "L", "START"
        if (!NativeBridge.isEngineAvailable()) return
        NativeBridge.sendInput(button, pressed)
    }

    @JavascriptInterface
    fun setAnalog(x: Float, y: Float) {
        if (!NativeBridge.isEngineAvailable()) return
        NativeBridge.setAnalog(x, y)
    }

    fun notifyEngineNotConnected() {
        webView.post {
            webView.evaluateJavascript(
                "window.dispatchEvent(new CustomEvent('mypsp-engine-not-connected'))",
                null
            )
        }
    }

    private fun errorJson(code: String, message: String): String {
        return JSONObject().apply {
            put("ok", false)
            put("code", code)
            put("message", message)
        }.toString()
    }

    private fun successJson(code: String, path: String): String {
        return JSONObject().apply {
            put("ok", true)
            put("code", code)
            put("path", path)
        }.toString()
    }
}
