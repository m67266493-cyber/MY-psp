package com.mypsp

import android.os.Bundle
import android.view.SurfaceView
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity

/**
 * GameActivity - شاشة اللعب الحقيقية
 * تعرض SurfaceView الذي يرسم عليه محرك PPSSPP.
 * لا تعرض أي لعب وهمي.
 */
class GameActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gamePath = intent.getStringExtra("game_path") ?: ""
        val container = FrameLayout(this)
        val surface = SurfaceView(this)
        container.addView(surface)
        setContentView(container)

        if (!NativeBridge.isEngineAvailable()) {
            finish()
            return
        }
        // بعد ربط PPSSPP، هنا يتم تمرير الـ Surface إلى المحرك
        // PpssppIntegration.startGame(surface, gamePath)
        NativeBridge.launchGameNative(gamePath)
    }
}
