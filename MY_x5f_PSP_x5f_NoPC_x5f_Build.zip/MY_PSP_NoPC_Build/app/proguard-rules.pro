# MY PSP - keep bridge classes
-keep class com.mypsp.PpssppBridge { *; }
-keep class com.mypsp.NativeBridge { *; }
-keep class com.mypsp.MainActivity { *; }
