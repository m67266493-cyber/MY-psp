# MY PSP — نسخة دائمة OFFLINE — بدون إنترنت نهائياً

> **هذا المشروع لا يحتاج إنترنت أبداً بعد التحميل. لا سيرفر، لا اشتراك، لا اتصال بنا. ملفاتك عندك، انسخها واحتفظ بها.**

# MY PSP — مشروع أندرويد كامل + محرك PPSSPP الرسمي

هذا هو مشروع الخطوة الثالثة: واجهة MY PSP + جسر رسمي لمحرك PPSSPP.
**لا يحتوي هذا المشروع على ألعاب تجارية ولا على ملفات نظام سوني.**
المحرك يُسحب من المصدر الرسمي المفتوح لـ PPSSPP.

## ما الذي تم بناؤه لك؟

- واجهة MY PSP كاملة داخل `app/src/main/assets/www/index.html`
- `MainActivity` بـ WebView يعرض الواجهة
- `PpssppBridge` = الجسر بين الواجهة (JavaScript) والأندرويد (Kotlin)
- `NativeBridge` + `native-lib.cpp` = الجسر بين Kotlin و C++ (JNI)
- نقطة ربط واضحة لمحرك PPSSPP في `app/src/main/cpp/ppsspp_integration.cpp`
- مدير مكتبة ألعاب يقرأ ملفات ISO/CSO التي يملكها المستخدم قانونياً فقط

## كيف تشغّل المشروع؟ (الطريقة الرسمية)

### 1. المتطلبات
- Android Studio Hedgehog أو أحدث
- Android SDK 34
- NDK 25+ و CMake 3.22+
- Git

### 2. سحب محرك PPSSPP الرسمي
افتح Terminal داخل مجلد المشروع ونفذ:

```bash
git submodule update --init --recursive
# هذا يسحب https://github.com/hrydgard/ppsspp إلى مجلد ppsspp/
```

إذا لم يعمل الـ submodule، نفذ يدوياً:
```bash
git clone https://github.com/hrydgard/ppsspp.git ppsspp
cd ppsspp
git submodule update --init --recursive
```

### 3. افتح المشروع
- افتح Android Studio > Open > اختر مجلد MY_PSP_Android_Project
- انتظر اكتمال Gradle Sync
- وصّل هاتف أندرويد أو شغّل محاكي
- اضغط Run

### 4. كيف تضيف لعبة؟
- من داخل التطبيق اضغط Add Game
- اختر ملف ISO / CSO / PBP **منسوخ من لعبتك الأصلية التي تملكها**
- التطبيق لا يأتي مع أي لعبة.

## كيف يعمل الجسر؟

```
واجهة MY PSP (index.html / JavaScript)
  ↓ window.MYPSP_Bridge.launchGame(path)
Kotlin: PpssppBridge (JavascriptInterface)
  ↓ NativeBridge.launchGameNative(path)
C++: native-lib.cpp (JNI)
  ↓ PPSSPP Core (ppsspp/ - من المصدر الرسمي)
PPSSPP Emulator Engine
```

إذا لم يكن المحرك مترجماً بعد، الواجهة تعرض بصدق:
**"Engine Not Connected"** ولا تدّعي تشغيل اللعبة.

## ملفات مهمة

| الملف | وظيفته |
|---|---|
| `app/src/main/java/com/mypsp/MainActivity.kt` | الشاشة الرئيسية + WebView |
| `app/src/main/java/com/mypsp/PpssppBridge.kt` | جسر JavaScript ↔ Android |
| `app/src/main/cpp/native-lib.cpp` | جسر JNI |
| `app/src/main/cpp/ppsspp_integration.cpp` | نقطة ربط PPSSPP - هنا تضع استدعاءات المحرك |
| `app/src/main/assets/www/index.html` | واجهة MY PSP |
| `.gitmodules` | رابط PPSSPP الرسمي |

## ملاحظة قانونية
- لا ترسل / لا ترفع ألعاب ISO تجارية.
- لا تستخدم ملفات BIOS أو Firmware من سوني. PPSSPP لا يحتاجها.
- استخدم فقط نسخاً قمت بنسخها بنفسك من ألعابك الأصلية.

## ماذا بعد؟
1. بعد تشغيل المشروع لأول مرة، أرسل لي لقطة شاشة لأي خطأ في Gradle Sync وسأصلحه لك.
2. إذا أردت APK جاهز، أخبرني وسأجهز لك تعليمات بناء APK من Android Studio.


---

## 🆕 فكرة جديدة: زر تحميل النظام من ZIP

**فكرة المستخدم - تم تنفيذها.**

### ليش الفكرة ممتازة؟
- أنت عندك النظام الحقيقي جاهز، ما تحتاج تبنيه من الصفر من GitHub.
- اللاعب نفسه يقدر يجيب نظامه الخاص بصيغة ZIP.
- التطبيق يصير مرن: أي نظام PPSSPP بصيغة ZIP يشتغل.

### كيف تستخدمها؟
1. جهّز ملف ZIP فيه نظام PPSSPP الحقيقي. مثال على المحتوى الصح:
```
engine/
  libppsspp.so
  config.ini
  assets/...
```
أو مجلد PPSSPP مضغوط مباشرة.

2. في التطبيق: اذهب إلى System > تحميل النظام من ZIP > اختر ملف ZIP
3. التطبيق يفك الضغط في `filesDir/engine/` ويتحقق من الملفات.
4. إذا صح، تطلع لك: "تم تحميل النظام بنجاح!"
5. أعد تشغيل التطبيق، وجرّب Launch — رسالة Engine Not Connected بتختفي.

### ما الذي لا يقبله الزر؟
- ملف لعبة ISO / CSO — هذا مو نظام، هذا لعبة. الألعاب تنضاف من Add Game.
- ملفات Firmware من سوني — PPSSPP لا يحتاجها.
- ZIP فاضي أو فيه صور فقط.

### أمان
- الملف يُفك في مجلد خاص بالتطبيق فقط، لا يصل لملفات النظام الأخرى.
- يوجد حماية من Zip Slip.
- لا تستخدم ZIP من مصدر غير موثوق.

### الملفات الجديدة لهذه الميزة
- `EngineZipLoader.kt` — فك الضغط والتحقق
- `MainActivity.kt` — منتقي الملفات `openEngineZipPicker()`
- `PpssppBridge.kt` — `requestEngineZipPicker()` + `isEngineLoadedFromZip()` + `getEngineInfo()`
- `index.html` — زر "اختر ملف ZIP فيه النظام"
